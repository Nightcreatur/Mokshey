import WebRoutes from "./routes/Routes";
const App = () => {
  return (
    <>
      <WebRoutes />
    </>
  );
};

export default App;
