export const galleryImages = [
  {
    id: 1,
    url: "path/to/image1.jpg",
    alt: "Image 1",
    caption: "Caption for image 1",
  },
  {
    id: 2,
    url: "path/to/image2.jpg",
    alt: "Image 2",
    caption: "Caption for image 2",
  },
  {
    id: 3,
    url: "path/to/image3.jpg",
    alt: "Image 3",
    caption: "Caption for image 3",
  },
  {
    id: 3,
    url: "path/to/image3.jpg",
    alt: "Image 3",
    caption: "Caption for image 3",
  },
  {
    id: 3,
    url: "path/to/image3.jpg",
    alt: "Image 3",
    caption: "Caption for image 3",
  },
  {
    id: 3,
    url: "path/to/image3.jpg",
    alt: "Image 3",
    caption: "Caption for image 3",
  },
  {
    id: 3,
    url: "path/to/image3.jpg",
    alt: "Image 3",
    caption: "Caption for image 3",
  },
  // Add more images here
];
