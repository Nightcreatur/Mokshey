export const links = [
  { name: "Open roles", href: "#" },
  { name: "Internship program", href: "#" },
  { name: "Our values", href: "#" },
  { name: "Meet our leadership", href: "#" },
];
export const stats = [
  { name: "Offices worldwide", value: "12" },
  { name: "Full-time colleagues", value: "300+" },
  { name: "Hours per week", value: "40" },
  { name: "Paid time off", value: "Unlimited" },
];
export const teamMembers = [
  {
    id: 1,
    name: "John Doe",
    role: "Lead Developer",
    imageUrl: "path/to/john-image.jpg",
    bio: "John is a seasoned developer with 10 years of experience in full stack development.",
    href: "/team/john-doe",
  },
  {
    id: 2,
    name: "Jane Smith",
    role: "UI/UX Designer",
    imageUrl: "path/to/jane-image.jpg",
    bio: "Jane is passionate about creating intuitive and beautiful user interfaces.",
    href: "/team/jane-smith",
  },
  {
    id: 2,
    name: "Jane Smith",
    role: "UI/UX Designer",
    imageUrl: "path/to/jane-image.jpg",
    bio: "Jane is passionate about creating intuitive and beautiful user interfaces.",
    href: "/team/jane-smith",
  },
  {
    id: 2,
    name: "Jane Smith",
    role: "UI/UX Designer",
    imageUrl: "path/to/jane-image.jpg",
    bio: "Jane is passionate about creating intuitive and beautiful user interfaces.",
    href: "/team/jane-smith",
  },
  {
    id: 2,
    name: "Jane Smith",
    role: "UI/UX Designer",
    imageUrl: "path/to/jane-image.jpg",
    bio: "Jane is passionate about creating intuitive and beautiful user interfaces.",
    href: "/team/jane-smith",
  },
  {
    id: 2,
    name: "Jane Smith",
    role: "UI/UX Designer",
    imageUrl: "path/to/jane-image.jpg",
    bio: "Jane is passionate about creating intuitive and beautiful user interfaces.",
    href: "/team/jane-smith",
  },
  // Add more team members here
];
